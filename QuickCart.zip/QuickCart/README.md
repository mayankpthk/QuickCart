# ⚡ QuickCart — Groceries in 10 Minutes

A fully modular, Progressive Web App (PWA) for fast grocery delivery.  
Built with vanilla HTML, CSS, and JavaScript — zero dependencies.

---

## 📁 Project Structure

```
QuickCart/
├── index.html          ← Main HTML shell
├── manifest.json       ← PWA manifest
├── sw.js               ← Service Worker (offline support)
│
├── css/
│   ├── styles.css      ← Base: variables, header, banner, products, layout
│   ├── auth.css        ← Auth page (login / signup)
│   └── cart.css        ← Cart, order form, success, toast, panels, install
│
├── js/
│   ├── main.js         ← App boot + service worker registration
│   ├── auth.js         ← Login, signup, logout, session
│   ├── cart.js         ← Cart state, checkout, order placement
│   ├── products.js     ← Product & category rendering
│   ├── ui.js           ← Toast, search, location, profile, orders, PWA install
│   └── storage.js      ← localStorage helper functions
│
├── data/
│   └── products.js     ← All product data, categories, offers, config
│
└── assets/
    └── images/         ← Place local product images here (optional)
```

---

## 🚀 Features

- 🔐 Auth — Login / Signup with localStorage persistence
- 🛒 Cart — Add, remove, adjust quantities with live totals
- 📦 Checkout — WhatsApp order + email notification + Google Sheets logging
- 👤 Profile — Saved addresses, order history
- 🔍 Search — Instant product search with dropdown
- 📍 Location — Geolocation with reverse geocoding (OpenStreetMap)
- 📲 PWA — Installable, offline-capable via Service Worker
- 📱 Responsive — Mobile-first with bottom nav

---

## ⚙️ Configuration

Open `data/products.js` and update:

```js
const SHOP_WA    = '91XXXXXXXXXX';          // Your WhatsApp number
const SHOP_EMAIL = 'you@example.com';       // Order notification email
const SHEET_URL  = 'https://script.google.com/macros/s/YOUR_ID/exec'; // Optional
```

---

## 🌐 Deployment

Works on any static host:
- **GitHub Pages** — push to `gh-pages` branch
- **Netlify / Vercel** — drag & drop the folder
- **Firebase Hosting** — `firebase deploy`

> ⚠️ HTTPS is required for PWA install prompts and geolocation.

---

## 🛠️ Google Sheets Integration (optional)

1. Go to [Google Apps Script](https://script.google.com)
2. Create a new project and paste a POST webhook script
3. Deploy as a Web App → copy the URL into `SHEET_URL` in `data/products.js`

---

© 2025 QuickCart. All rights reserved.
